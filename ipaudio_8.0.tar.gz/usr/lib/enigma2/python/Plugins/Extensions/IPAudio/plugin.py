# -*- coding: utf-8 -*-
import sys
import os
import io
import json
import subprocess
import signal
import traceback
from datetime import datetime
from collections import OrderedDict

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

try:
    from Plugins.Plugin import PluginDescriptor
    from Screens.Screen import Screen
    from Components.Label import Label
    from Components.ActionMap import ActionMap
    from Components.Button import Button
    from Screens.MessageBox import MessageBox
    from Components.MenuList import MenuList
    from Tools.BoundFunction import boundFunction
    from GlobalActions import globalActionMap
    
    try:
        from keymapparser import readKeymap
    except ImportError:
        from Components.ActionMap import loadKeymap as readKeymap
        
    from Components.Sources.StaticText import StaticText
    from Components.config import (
        config, ConfigSelectionNumber, getConfigListEntry, ConfigSelection, 
        ConfigYesNo, ConfigInteger, ConfigSubsection, ConfigText, configfile, 
        NoSave
    )
    from Components.ConfigList import ConfigListScreen
    from Tools.Directories import resolveFilename, SCOPE_PLUGINS
    from enigma import eConsoleAppContainer, getDesktop, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, RT_WRAP
    from enigma import iPlayableService, eTimer, loadPNG
    from Components.ServiceEventTracker import ServiceEventTracker
    from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
    from Tools.Directories import fileExists
    
    try:
        from enigma import eAlsaOutput
        HAVE_EALSA = True
    except ImportError:
        HAVE_EALSA = False
        
    from Plugins.Extensions.IPAudio.Console2 import Console2
    try:
        from .skin import *
    except ImportError:
        pass
except ImportError as e:
    print("[IPAudio] Import error:", str(e))
    traceback.print_exc()

MAXDELAY = 50

config.plugins.IPAudio = ConfigSubsection()
config.plugins.IPAudio.currentService = ConfigText()
config.plugins.IPAudio.player = ConfigSelection(default="gst1.0-ipaudio", choices=[
    ("gst1.0-ipaudio", "Gstreamer"),
    ("ff-ipaudio", "FFmpeg"),
])
config.plugins.IPAudio.sync = ConfigSelection(default="alsasink", choices=[
    ("alsasink", "alsasink"),
    ("osssink", "osssink"),
    ("autoaudiosink", "autoaudiosink"),
])
config.plugins.IPAudio.skin = ConfigSelection(default="orange", choices=[
    ("orange", "Orange"),
    ("teal", "Teal"),
    ("lime", "Lime")
])
config.plugins.IPAudio.update = ConfigYesNo(default=True)
config.plugins.IPAudio.mainmenu = ConfigYesNo(default=False)
config.plugins.IPAudio.keepaudio = ConfigYesNo(default=False)
config.plugins.IPAudio.volLevel = ConfigSelectionNumber(default=1, stepwidth=1, min=1, max=10, wraparound=True)
config.plugins.IPAudio.audioDelay = ConfigInteger(default=0, limits=(-10000, 10000))
config.plugins.IPAudio.tsDelay = ConfigInteger(default=10, limits=(1, MAXDELAY * 2))
config.plugins.IPAudio.delay = NoSave(ConfigInteger(default=10, limits=(1, MAXDELAY * 2)))
config.plugins.IPAudio.playlist = ConfigSelection(choices=[("1", "Press OK")], default="1")
config.plugins.IPAudio.running = ConfigYesNo(default=False)
config.plugins.IPAudio.lastidx = ConfigText()
config.plugins.IPAudio.lastplayed = NoSave(ConfigText())
config.plugins.IPAudio.equalizer = ConfigSelection(default="off", choices=[
    ("off", "Off"),
    ("bass_boost", "Bass Boost"),
    ("treble_boost", "Treble Boost"),
    ("vocal", "Vocal Enhance"),
    ("rock", "Rock"),
    ("pop", "Pop"),
    ("classical", "Classical"),
    ("jazz", "Jazz"),
])

REDC = '\033[31m'
ENDC = '\033[m'

def cprint(text):
    print(REDC + text + ENDC)

def trace_error():
    try:
        traceback.print_exc(file=sys.stdout)
        with open('/tmp/IPAudio.log', 'a') as f:
            traceback.print_exc(file=f)
    except:
        pass

PLAYLIST_DIR = '/etc/enigma2/ipaudio/'

def getPlaylistFiles():
    import glob
    
    if not os.path.exists(PLAYLIST_DIR):
        os.makedirs(PLAYLIST_DIR)
    
    playlist_files = glob.glob(PLAYLIST_DIR + 'ipaudio_*.json')
    playlists = []
    
    for filepath in sorted(playlist_files):
        filename = os.path.basename(filepath)
        category = filename.replace('ipaudio_', '').replace('.json', '')
        category = category.capitalize()
        playlists.append({'name': category, 'file': filepath})
    
    return playlists

def getPlaylist(category_file=None):
    if category_file is None:
        category_file = '/etc/enigma2/ipaudio.json'
    
    if fileExists(category_file):
        try:
            if PY2:
                with open(category_file, 'r') as f:
                    return json.loads(f.read(), object_pairs_hook=OrderedDict)
            else:
                with io.open(category_file, 'r', encoding='utf-8') as f:
                    return json.loads(f.read(), object_pairs_hook=OrderedDict)
        except ValueError:
            trace_error()
    return None

def getversioninfo():
    currversion = "1.0"
    versionfile = "/usr/lib/enigma2/python/Plugins/Extensions/IPAudio/version"
    
    if os.path.exists(versionfile):
        try:
            if PY2:
                with open(versionfile, 'r') as fp:
                    for line in fp.readlines():
                        if 'version=' in line:
                            currversion = line.split('=')[1].strip()
                            break
            else:
                with io.open(versionfile, 'r', encoding='utf-8') as fp:
                    for line in fp.readlines():
                        if 'version=' in line:
                            currversion = line.split('=')[1].strip()
                            break
        except:
            pass
    
    return currversion

Ver = getversioninfo()

def getPiconPath(serviceName):
    picon_paths = [
        '/etc/enigma2/picon/',
        '/usr/lib/enigma2/python/Plugins/Extensions/IPAudio/picons'
    ]
    
    clean_name = serviceName.lower().replace(' ', '_').replace('+', 'plus')
    clean_name = ''.join(c for c in clean_name if c.isalnum() or c == '_')
    
    for path in picon_paths:
        if os.path.exists(path):
            picon_file = os.path.join(path, clean_name + '.png')
            if os.path.exists(picon_file):
                return picon_file
            
            try:
                for filename in os.listdir(path):
                    if clean_name in filename.lower() and filename.endswith('.png'):
                        return os.path.join(path, filename)
            except:
                pass
    
    default_picon = '/usr/lib/enigma2/python/Plugins/Extensions/IPAudio/default_picon.png'
    if os.path.exists(default_picon):
        return default_picon
    return None

def isMutable():
    if fileExists('/proc/stb/info/boxtype'):
        with open('/proc/stb/info/boxtype', 'r') as f:
            boxtype = f.read().strip()
            return boxtype in ('sf8008', 'sf8008m', 'viper4kv20', 'beyonwizv2', 'ustym4kpro', 'gbtrio4k', 'spider-x')
    return False

def getDesktopSize():
    s = getDesktop(0).size()
    return (s.width(), s.height())

def isHD():
    desktopSize = getDesktopSize()
    return desktopSize[0] == 1280

class IPAudioSetup(Screen, ConfigListScreen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.currentSkin = config.plugins.IPAudio.skin.value
        
        if isHD():
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioSetup_ORANGE_HD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioSetup_TEAL_HD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioSetup_LIME_HD
            else:
                self.skin = SKIN_IPAudioSetup_ORANGE_HD
        else:
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioSetup_ORANGE_FHD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioSetup_TEAL_FHD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioSetup_LIME_FHD
            else:
                self.skin = SKIN_IPAudioSetup_ORANGE_FHD
        
        self.skinName = "IPAudioSetup"
        self.onChangedEntry = []
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=session, on_change=self.changedEntry)
        self["actions"] = ActionMap(["SetupActions"],
            {
                "cancel": self.keyCancel,
                "save": self.apply,
                "ok": self.apply,
            }, -2)
        self["key_green"] = StaticText("Save")
        self["key_red"] = StaticText("Cancel")
        self.configChanged = False
        self.createSetup()

    def createSetup(self):
        self.list = [getConfigListEntry("Player", config.plugins.IPAudio.player)]
        if config.plugins.IPAudio.player.value == "gst1.0-ipaudio":
            self.list.append(getConfigListEntry("Sync Audio using", config.plugins.IPAudio.sync))
            self.list.append(getConfigListEntry("Audio Equalizer", config.plugins.IPAudio.equalizer))
        self.list.append(getConfigListEntry("External links volume level", config.plugins.IPAudio.volLevel))
        self.list.append(getConfigListEntry("Keep original channel audio", config.plugins.IPAudio.keepaudio))
        self.list.append(getConfigListEntry("Video Delay", config.plugins.IPAudio.tsDelay))
        self.list.append(getConfigListEntry("Audio Delay", config.plugins.IPAudio.audioDelay))
        self.list.append(getConfigListEntry("Remove/Reset Playlist", config.plugins.IPAudio.playlist))
        self.list.append(getConfigListEntry("Enable/Disable online update", config.plugins.IPAudio.update))
        self.list.append(getConfigListEntry("Show IPAudio in main menu", config.plugins.IPAudio.mainmenu))
        self.list.append(getConfigListEntry("Select Your IPAudio Skin", config.plugins.IPAudio.skin))
        self["config"].list = self.list
        self["config"].setList(self.list)

    def apply(self):
        current = self["config"].getCurrent()
        if current[1] == config.plugins.IPAudio.playlist:
            self.session.open(IPAudioPlaylist)
        else:
            for x in self["config"].list:
                if len(x) > 1:
                    x[1].save()
            configfile.save()
            
            if self.currentSkin != config.plugins.IPAudio.skin.value:
                self.session.open(MessageBox, "Skin changed! Please restart IPAudio plugin for changes to take effect.", MessageBox.TYPE_INFO, timeout=5)
            
            self.close(False)

    def keyCancel(self):
        for x in self["config"].list:
            if len(x) > 1:
                x[1].cancel()
        self.close(False)

    def changedEntry(self):
        for x in self.onChangedEntry:
            x()
        current = self["config"].getCurrent()
        if current[1] == config.plugins.IPAudio.player:
            self.createSetup()

class IPAudioScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        
        if isHD():
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioScreen_ORANGE_HD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioScreen_TEAL_HD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioScreen_LIME_HD
            else:
                self.skin = SKIN_IPAudioScreen_ORANGE_HD
        else:
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioScreen_ORANGE_FHD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioScreen_TEAL_FHD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioScreen_LIME_FHD
            else:
                self.skin = SKIN_IPAudioScreen_ORANGE_FHD
        
        self.choices = list(self.getHosts())
        self.plIndex = 0
        self['title'] = Label()
        self['title'].setText('IPAudio v{}'.format(Ver))
        self['server'] = Label()
        self['sync'] = Label()
        
        delay_seconds = config.plugins.IPAudio.tsDelay.value / 2.0
        self['sync'].setText('Video Delay: {:.1f}s'.format(delay_seconds))
        
        self['audio_delay'] = Label()
        self['audio_delay'].setText('Audio Delay: {}ms'.format(config.plugins.IPAudio.audioDelay.value))
        self['network_status'] = Label()
        self['network_status'].setText('')
        
        self["list"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        
        if isHD():
            self["list"].l.setItemHeight(40)
            self["list"].l.setFont(0, gFont('Regular', 20))
        else:
            self["list"].l.setItemHeight(50)
            self["list"].l.setFont(0, gFont('Regular', 28))
        
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Reset Audio")
        self["key_yellow"] = Button("Help")
        self["key_blue"] = Button("Info")
        self["key_menu"] = Button("Menu")
        self["IPAudioAction"] = ActionMap(["IPAudioActions", "ColorActions"],
            {
                "ok": self.ok,
                "ok_long": boundFunction(self.ok, long=True),
                "cancel": self.exit,
                "menu": self.openConfig,
                "red": self.exit,
                "green": self.resetAudio,
                "yellow": self.showHelp,
                "blue": self.showInfo,
                "right": self.right,
                "left": self.left,
                "pause": self.pause,
                "pauseAudio": self.pauseAudioProcess,
                "delayUP": self.delayUP,
                "delayDown": self.delayDown,
                "audioDelayDown": self.audioDelayDown,
                "audioDelayReset": self.audioDelayReset,
                "audioDelayUp": self.audioDelayUp,
            }, -1)
        
        self.alsa = None
        self.audioPaused = False
        self.audio_process = None
        self.radioList = []
        self.guide = dict()
        
        if HAVE_EALSA:
            self.alsa = eAlsaOutput.getInstance()
        
        self.timeShiftTimer = eTimer()
        self.guideTimer = eTimer()
        self.statusTimer = eTimer()
        
        try:
            self.timeShiftTimer.callback.append(self.unpauseService)
            self.guideTimer.callback.append(self.getGuide)
            self.statusTimer.callback.append(self.checkNetworkStatus)
        except AttributeError:
            self.timeShiftTimer_conn = self.timeShiftTimer.timeout.connect(self.unpauseService)
            self.guideTimer_conn = self.guideTimer.timeout.connect(self.getGuide)
            self.statusTimer_conn = self.statusTimer.timeout.connect(self.checkNetworkStatus)
        
        self.lastservice = self.session.nav.getCurrentlyPlayingServiceReference()
        
        if config.plugins.IPAudio.update.value:
            self.checkupdates()
        
        self.onLayoutFinish.append(self.getGuide)
        self.onShown.append(self.onWindowShow)

    def showInfo(self):
        self.session.open(IPAudioInfo)

    def showHelp(self):
        self.session.open(IPAudioHelp)

    def checkNetworkStatus(self):
        if self.audio_process:
            if self.audio_process.poll() is None:
                self['network_status'].setText(u'\u25CF Playing')
            else:
                self['network_status'].setText(u'\u2717 Stopped')
                self.audio_process = None
        else:
            self['network_status'].setText('')

    def getTimeshift(self):
        service = self.session.nav.getCurrentService()
        return service and service.timeshift()

    def pauseAudioProcess(self):
        if config.plugins.IPAudio.running.value and IPAudioHandler.container.running():
            pid = IPAudioHandler.container.getPID()
            if not self.audioPaused:
                cmd = "kill -STOP {}".format(pid)
                self.audioPaused = True
            else:
                cmd = "kill -CONT {}".format(pid)
                self.audioPaused = False
            eConsoleAppContainer().execute(cmd)

    def pause(self):
        if config.plugins.IPAudio.running.value:
            ts = self.getTimeshift()
            
            delay_ms = config.plugins.IPAudio.tsDelay.value * 500
            
            if ts is not None and not ts.isTimeshiftEnabled():
                ts.startTimeshift()
                ts.activateTimeshift()
                self.timeShiftTimer.start(delay_ms, False)
                config.plugins.IPAudio.delay.value = config.plugins.IPAudio.tsDelay.value
            elif ts is not None and ts.isTimeshiftEnabled() and not self.timeShiftTimer.isActive():
                current_delay_ms = config.plugins.IPAudio.delay.value * 500
                
                if config.plugins.IPAudio.delay.value != config.plugins.IPAudio.tsDelay.value:
                    service = self.session.nav.getCurrentService()
                    pauseable = service.pause()
                    if pauseable:
                        pauseable.pause()
                    
                    remaining_delay = delay_ms - current_delay_ms
                    self.timeShiftTimer.start(remaining_delay, False)
                    config.plugins.IPAudio.delay.value = config.plugins.IPAudio.tsDelay.value
                    
                    if config.plugins.IPAudio.delay.value == config.plugins.IPAudio.tsDelay.value:
                        ts.stopTimeshift()
                        ts.startTimeshift()
                        ts.activateTimeshift()
                        self.timeShiftTimer.start(delay_ms, False)
                        config.plugins.IPAudio.delay.value = config.plugins.IPAudio.tsDelay.value

    def unpauseService(self):
        self.timeShiftTimer.stop()
        service = self.session.nav.getCurrentService()
        pauseable = service.pause()
        if pauseable:
            pauseable.unpause()

    def delayUP(self):
        if config.plugins.IPAudio.tsDelay.value < MAXDELAY * 2:
            config.plugins.IPAudio.tsDelay.value += 1
            config.plugins.IPAudio.tsDelay.save()
            delay_seconds = config.plugins.IPAudio.tsDelay.value / 2.0
            self['sync'].setText('Video Delay: {:.1f}s'.format(delay_seconds))

    def delayDown(self):
        if config.plugins.IPAudio.tsDelay.value > 1:
            config.plugins.IPAudio.tsDelay.value -= 1
            config.plugins.IPAudio.tsDelay.save()
            delay_seconds = config.plugins.IPAudio.tsDelay.value / 2.0
            self['sync'].setText('Video Delay: {:.1f}s'.format(delay_seconds))

    def getHosts(self):
        hosts = resolveFilename(SCOPE_PLUGINS, "Extensions/IPAudio/hosts.json")
        self.hosts = None
        
        if fileExists(hosts):
            try:
                if PY2:
                    with open(hosts, 'r') as f:
                        hosts_content = f.read()
                else:
                    with io.open(hosts, 'r', encoding='utf-8') as f:
                        hosts_content = f.read()
                        
                self.hosts = json.loads(hosts_content, object_pairs_hook=OrderedDict)
                for host in self.hosts:
                    yield host
            except Exception as e:
                cprint("[IPAudio] Error loading hosts: {}".format(str(e)))
                trace_error()
        
        custom_playlists = getPlaylistFiles()
        for playlist in custom_playlists:
            yield playlist['name']

    def onWindowShow(self):
        self.onShown.remove(self.onWindowShow)
        self.guideTimer.start(30000)
        if config.plugins.IPAudio.lastidx.value:
            try:
                last_playlist, last_channel = map(int, config.plugins.IPAudio.lastidx.value.split(','))
                self.plIndex = last_playlist
                self.changePlaylist()
                self["list"].moveToIndex(last_channel)
            except:
                self.setPlaylist()
        else:
            self.setPlaylist()

    def checkupdates(self):
        url = "https://raw.githubusercontent.com/popking159/ipaudio/main/installer-ipaudio.sh"
        self.callUrl(url, self.checkVer)

    def checkVer(self, data):
        try:
            if PY2:
                data = data
            else:
                data = data.decode('utf-8')
            
            if data:
                lines = data.split('\n')
                self.newversion = None
                self.newdescription = ""
                
                for line in lines:
                    line = line.strip()
                    if line.startswith('version='):
                        self.newversion = line.split('=')[1].strip('"').strip("'")
                    elif line.startswith('description='):
                        self.newdescription = line.split('=')[1].strip('"').strip("'")
                
                if self.newversion:
                    cprint("[IPAudio] Current version: {}, New version: {}".format(Ver, self.newversion))
                    
                    try:
                        current = float(Ver)
                        new = float(self.newversion)
                        
                        if new > current:
                            msg = "New version {} is available.\n\n{}\n\nDo you want to install it now?".format(
                                self.newversion, 
                                self.newdescription
                            )
                            self.session.openWithCallback(
                                self.installupdate, 
                                MessageBox, 
                                msg, 
                                MessageBox.TYPE_YESNO
                            )
                    except ValueError:
                        cprint("[IPAudio] Could not compare versions")
        except Exception as e:
            cprint("[IPAudio] Error checking version: {}".format(str(e)))
            trace_error()

    def installupdate(self, answer=False):
        if answer:
            url = "https://raw.githubusercontent.com/popking159/ipaudio/main/installer-ipaudio.sh"
            cmdlist = []
            cmdlist.append('wget -q --no-check-certificate {} -O - | bash'.format(url))
            self.session.open(
                Console2, 
                title="Update IPAudio", 
                cmdlist=cmdlist, 
                closeOnSuccess=False
            )

    def callUrl(self, url, callback):
        try:
            if PY2:
                from twisted.web.client import getPage
                getPage(url).addCallback(callback).addErrback(self.addErrback)
            else:
                from twisted.web.client import Agent, readBody
                from twisted.internet import reactor
                
                agent = Agent(reactor)
                d = agent.request(b'GET', url.encode('utf-8'))
                d.addCallback(lambda response: readBody(response))
                d.addCallback(callback)
                d.addErrback(self.addErrback)
        except Exception as e:
            cprint("[IPAudio] Error in callUrl: {}".format(str(e)))

    def getAnisUrls(self):
        url = "https://raw.githubusercontent.com/popking159/ipaudio/refs/heads/main/ipaudio_anis.json"
        self.callUrl(url, self.parseAnisData)

    def parseAnisData(self, data):
        try:
            if PY2:
                data = data
            else:
                data = data.decode('utf-8')
            
            playlist_data = json.loads(data, object_pairs_hook=OrderedDict)
            list = []
            
            if 'playlist' in playlist_data:
                for channel in playlist_data['playlist']:
                    try:
                        list.append([str(channel['channel']), str(channel['url'])])
                    except KeyError:
                        pass
            
            if len(list) > 0:
                self["list"].l.setList(self.iniMenu(list))
                self["list"].show()
                self.radioList = list
            else:
                self["list"].hide()
                self.radioList = []
                self['server'].setText('Anis Sport - Playlist is empty')
        except Exception as e:
            cprint("[IPAudio] Error parsing Anis data: {}".format(str(e)))
            trace_error()
            self["list"].hide()
            self.radioList = []
            self['server'].setText('Error loading Anis Sport')

    def addErrback(self, error=None):
        pass

    def right(self):
        self.plIndex += 1
        self.changePlaylist()

    def left(self):
        self.plIndex -= 1
        self.changePlaylist()

    def changePlaylist(self):
        if self.plIndex > len(self.choices) - 1:
            self.plIndex = 0
        if self.plIndex < 0:
            self.plIndex = len(self.choices) - 1
        
        self.radioList = []
        self.setPlaylist()

    def setPlaylist(self):
        if self.plIndex >= len(self.choices):
            self.plIndex = 0
            
        current = self.choices[self.plIndex]
        
        if hasattr(self, 'hosts') and current in self.hosts:
            if current in ["Anis Sport"]:
                self.getAnisUrls()
                self['server'].setText(str(current))
            else:
                list = []
                for cmd in self.hosts[current]['cmds']:
                    list.append([cmd.split('|')[0], cmd.split('|')[1]])
                list = self.checkINGuide(list)
                
                if len(list) > 0:
                    self["list"].l.setList(self.iniMenu(list))
                    self["list"].show()
                    self.radioList = list
                    self['server'].setText(str(current))
                else:
                    self["list"].hide()
                    self.radioList = []
                    self['server'].setText('Playlist is empty')
        else:
            category_lower = current.lower()
            playlist_file = PLAYLIST_DIR + 'ipaudio_{}.json'.format(category_lower)
            
            if fileExists(playlist_file):
                playlist = getPlaylist(playlist_file)
                if playlist:
                    list = []
                    for channel in playlist['playlist']:
                        try:
                            list.append([str(channel['channel']), str(channel['url'])])
                        except KeyError:
                            pass
                    
                    if len(list) > 0:
                        self["list"].l.setList(self.iniMenu(list))
                        self["list"].show()
                        self.radioList = list
                        self['server'].setText(current)
                    else:
                        self["list"].hide()
                        self.radioList = []
                        self['server'].setText('{} - Playlist is empty'.format(current))
                else:
                    self["list"].hide()
                    self.radioList = []
                    self['server'].setText('Cannot load playlist')
            else:
                self["list"].hide()
                self.radioList = []
                self['server'].setText('Playlist file not found')

    def checkINGuide(self, entries):
        for idx, entry in enumerate(entries):
            if entry[0] in self.guide:
                if self.guide[entry[0]]['check']:
                    nowIntimestamp = datetime.now().strftime('%s')
                    entryProgEnding = self.guide[entry[0]]['end']
                    if int(entryProgEnding) >= int(nowIntimestamp):
                        entries[idx] = (self.guide[entry[0]]['prog'], entry[1])
        return entries

    def getGuide(self):
        url = 'http://ipkinstall.ath.cx/ipaudio/epg.json'
        self.callUrl(url, self.parseGuide)

    def parseGuide(self, data):
        if PY2:
            data = data
        else:
            data = data.decode("utf-8")
        self.guide = json.loads(data, object_pairs_hook=OrderedDict)
        if self.guide != {}:
            self.setPlaylist()

    def iniMenu(self, sList):
        res = []
        gList = []
        
        for elem in sList:
            picon_path = getPiconPath(elem[0])
            
            if isHD():
                res.append(MultiContentEntryText(
                    pos=(0, 0), 
                    size=(0, 0), 
                    font=0, 
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, 
                    text='', 
                    border_width=3
                ))
                
                if picon_path:
                    pixmap = loadPNG(picon_path)
                    if pixmap:
                        res.append(MultiContentEntryPixmapAlphaTest(
                            pos=(10, 1), 
                            size=(100, 56), 
                            png=pixmap
                        ))
                        res.append(MultiContentEntryText(
                            pos=(120, 4), 
                            size=(440, 50), 
                            font=0, 
                            backcolor_sel=None, 
                            flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                            text=str(elem[0])
                        ))
                    else:
                        res.append(MultiContentEntryText(
                            pos=(5, 4), 
                            size=(560, 50), 
                            font=0, 
                            backcolor_sel=None, 
                            flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                            text=str(elem[0])
                        ))
                else:
                    res.append(MultiContentEntryText(
                        pos=(5, 4), 
                        size=(560, 50), 
                        font=0, 
                        backcolor_sel=None, 
                        flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                        text=str(elem[0])
                    ))
            else:
                res.append(MultiContentEntryText(
                    pos=(0, 0), 
                    size=(0, 0), 
                    font=0, 
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, 
                    text='', 
                    border_width=3
                ))
                
                if picon_path:
                    pixmap = loadPNG(picon_path)
                    if pixmap:
                        res.append(MultiContentEntryPixmapAlphaTest(
                            pos=(10, 1), 
                            size=(110, 48), 
                            png=pixmap
                        ))
                        res.append(MultiContentEntryText(
                            pos=(130, 4), 
                            size=(700, 42), 
                            font=0, 
                            backcolor_sel=None, 
                            flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                            text=str(elem[0])
                        ))
                    else:
                        res.append(MultiContentEntryText(
                            pos=(5, 4), 
                            size=(830, 42), 
                            font=0, 
                            backcolor_sel=None, 
                            flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                            text=str(elem[0])
                        ))
                else:
                    res.append(MultiContentEntryText(
                        pos=(5, 4), 
                        size=(830, 42), 
                        font=0, 
                        backcolor_sel=None, 
                        flags=RT_VALIGN_CENTER | RT_HALIGN_LEFT, 
                        text=str(elem[0])
                    ))
            
            gList.append(res)
            res = []
        
        return gList

    def ok(self, long=False):
        if not hasattr(self, 'radioList') or len(self.radioList) == 0:
            self.session.open(MessageBox, "Playlist is empty! Please add channels first.", MessageBox.TYPE_INFO, timeout=5)
            return
        
        index = self['list'].getSelectionIndex()
        if index is None or index < 0 or index >= len(self.radioList):
            self.session.open(MessageBox, "Please select a channel first.", MessageBox.TYPE_INFO, timeout=5)
            return
        
        if config.plugins.IPAudio.player.value == "gst1.0-ipaudio":
            player_check = '/usr/bin/gst-launch-1.0'
        else:
            player_check = '/usr/bin/ffmpeg'
        
        if fileExists(player_check):
            currentAudioTrack = 0
            if long:
                service = self.session.nav.getCurrentService()
                if not service.streamed():
                    currentAudioTrack = service.audioTracks().getCurrentTrack()
                self.url = 'http://127.0.0.1:8001/{}'.format(self.lastservice.toString())
                config.plugins.IPAudio.lastplayed.value = "e2_service"
            else:
                try:
                    self.url = self.radioList[index][1]
                    config.plugins.IPAudio.lastplayed.value = self.url
                    config.plugins.IPAudio.lastidx.value = '{},{}'.format(self.plIndex, index)
                    config.plugins.IPAudio.lastidx.save()
                except (IndexError, KeyError) as e:
                    cprint("[IPAudio] Error accessing radioList: {}".format(str(e)))
                    self.session.open(MessageBox, "Error selecting channel.", MessageBox.TYPE_ERROR, timeout=5)
                    return
            
            if config.plugins.IPAudio.player.value == "gst1.0-ipaudio":
                eq_filter = self.getEqualizerFilter()
                
                sink = config.plugins.IPAudio.sync.value
                cmd = 'gst-launch-1.0 -e uridecodebin uri="{}" ! audioconvert ! audioresample ! '.format(self.url)
                
                if eq_filter:
                    cmd += '{} ! '.format(eq_filter)
                
                delay_ms = config.plugins.IPAudio.audioDelay.value
                if delay_ms != 0:
                    delay_ns = abs(delay_ms) * 1000000
                    if delay_ms > 0:
                        cmd += 'audiobuffersplit output-buffer-duration={} ! '.format(delay_ns)
                    else:
                        cmd += 'queue max-size-buffers=1 max-size-time=1000000 ! '
                
                cmd += '{} sync=false'.format(sink)
                
                if self.choices[self.plIndex] == 'Custom Playlist' and not long:
                    volume = config.plugins.IPAudio.volLevel.value / 10.0
                    cmd = cmd.replace('audioresample !', 'audioresample ! volume volume={} !'.format(volume))
                
                cprint("[IPAudio] GStreamer command: {}".format(cmd))
            else:
                delay_ms = config.plugins.IPAudio.audioDelay.value
                if delay_ms > 0:
                    cmd = 'ffmpeg -i "{}" -af "adelay={}|{}" -vn -f alsa default'.format(self.url, delay_ms, delay_ms)
                elif delay_ms < 0:
                    trim_sec = abs(delay_ms) / 1000.0
                    cmd = 'ffmpeg -ss {} -i "{}" -vn -f alsa default'.format(trim_sec, self.url)
                else:
                    cmd = 'ffmpeg -i "{}" -vn -f alsa default'.format(self.url)
                
                if currentAudioTrack > 0:
                    cmd = cmd.replace('-i', '-i').replace('-vn', '-map 0:a:{} -vn'.format(currentAudioTrack))
                
                cprint("[IPAudio] FFmpeg command: {}".format(cmd))
            
            self.runCmd(cmd)
        else:
            self.session.open(MessageBox, "Cannot play url, player is missing !!", MessageBox.TYPE_ERROR, timeout=5)

    def audioReStart(self):
        cprint("[IPAudio] audioReStart called")
        
        if self.audio_process:
            try:
                self.audio_process.kill()
                self.audio_process.wait(timeout=1)
                self.audio_process = None
            except:
                pass
        
        os.system("killall -9 gst-launch-1.0 ffmpeg 2>/dev/null")
        
        ts = self.getTimeshift()
        if ts and ts.isTimeshiftEnabled():
            ts.stopTimeshift()
        
        if self.timeShiftTimer.isActive():
            self.timeShiftTimer.stop()
        
        if fileExists('/dev/dvb/adapter0/audio10') and not isMutable():
            try:
                os.rename('/dev/dvb/adapter0/audio10', '/dev/dvb/adapter0/audio0')
            except:
                pass
            
            self.session.nav.stopService()
            self.restoreTimer = eTimer()
            try:
                self.restoreTimer.callback.append(self.restoreService)
            except AttributeError:
                self.restoreTimer_conn = self.restoreTimer.timeout.connect(self.restoreService)
            self.restoreTimer.start(100, True)
        elif config.plugins.IPAudio.running.value and isMutable():
            if IPAudioHandler.container.running():
                IPAudioHandler.container.kill()
        
        config.plugins.IPAudio.running.value = False
        config.plugins.IPAudio.running.save()

    def resetAudio(self):
        cprint("[IPAudio] resetAudio called")
        
        if self.statusTimer.isActive():
            self.statusTimer.stop()
        
        if self.audio_process:
            try:
                cprint("[IPAudio] Terminating process PID: {}".format(self.audio_process.pid))
                self.audio_process.terminate()
                try:
                    self.audio_process.wait(timeout=1)
                    cprint("[IPAudio] Process terminated gracefully")
                except subprocess.TimeoutExpired:
                    cprint("[IPAudio] Process not responding, force killing")
                    self.audio_process.kill()
                    self.audio_process.wait(timeout=1)
                    cprint("[IPAudio] Process force killed")
                self.audio_process = None
            except Exception as e:
                cprint("[IPAudio] Error killing process: {}".format(str(e)))
                try:
                    os.system("killall -9 gst-launch-1.0 ffmpeg 2>/dev/null")
                except:
                    pass
                self.audio_process = None
        else:
            cprint("[IPAudio] No process tracked, killing all gst-launch and ffmpeg")
            os.system("killall -9 gst-launch-1.0 ffmpeg 2>/dev/null")
        
        if IPAudioHandler.container.running():
            IPAudioHandler.container.kill()
        
        self['network_status'].setText('')
        
        if not self.alsa:
            if fileExists('/dev/dvb/adapter0/audio10') and not isMutable():
                try:
                    os.rename('/dev/dvb/adapter0/audio10', '/dev/dvb/adapter0/audio0')
                    cprint("[IPAudio] Audio device restored")
                except:
                    pass
                
                self.session.nav.stopService()
                self.restoreTimer = eTimer()
                try:
                    self.restoreTimer.callback.append(self.restoreService)
                except AttributeError:
                    self.restoreTimer_conn = self.restoreTimer.timeout.connect(self.restoreService)
                self.restoreTimer.start(100, True)
            elif isMutable():
                self.session.nav.stopService()
                self.restoreTimer = eTimer()
                try:
                    self.restoreTimer.callback.append(self.restoreService)
                except AttributeError:
                    self.restoreTimer_conn = self.restoreTimer.timeout.connect(self.restoreService)
                self.restoreTimer.start(100, True)
        
        config.plugins.IPAudio.running.value = False
        config.plugins.IPAudio.running.save()

    def restoreService(self):
        cprint("[IPAudio] Restoring service")
        self.session.nav.playService(self.lastservice)

    def runCmd(self, cmd):
        cprint("[IPAudio] runCmd called with: {}".format(cmd))
        
        if self.audio_process:
            try:
                self.audio_process.terminate()
                try:
                    self.audio_process.wait(timeout=1)
                except:
                    self.audio_process.kill()
            except:
                pass
            self.audio_process = None
        
        if IPAudioHandler.container.running():
            IPAudioHandler.container.kill()
        
        if self.alsa:
            self.alsa.stop()
            self.alsa.close()
        else:
            if not config.plugins.IPAudio.keepaudio.value:
                if fileExists('/dev/dvb/adapter0/audio0') and not isMutable():
                    self.session.nav.stopService()
                    try:
                        os.rename('/dev/dvb/adapter0/audio0', '/dev/dvb/adapter0/audio10')
                    except:
                        pass
                    self.session.nav.playService(self.lastservice)
        
        try:
            cprint("[IPAudio] Executing subprocess...")
            self.audio_process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid if hasattr(os, 'setsid') else None
            )
            cprint("[IPAudio] Process started with PID: {}".format(self.audio_process.pid))
        except Exception as e:
            cprint("[IPAudio] ERROR starting process: {}".format(str(e)))
            trace_error()
            self.audio_process = None
        
        config.plugins.IPAudio.running.value = True
        config.plugins.IPAudio.running.save()
        if not self.statusTimer.isActive():
            self.statusTimer.start(2000)

    def audioDelayUp(self):
        if config.plugins.IPAudio.audioDelay.value < 10000:
            config.plugins.IPAudio.audioDelay.value += 500
            config.plugins.IPAudio.audioDelay.save()
            self['audio_delay'].setText('Audio Delay: {}ms'.format(config.plugins.IPAudio.audioDelay.value))
            
            if config.plugins.IPAudio.running.value:
                self.restartAudioWithDelay()

    def audioDelayDown(self):
        if config.plugins.IPAudio.audioDelay.value > -10000:
            config.plugins.IPAudio.audioDelay.value -= 500
            config.plugins.IPAudio.audioDelay.save()
            self['audio_delay'].setText('Audio Delay: {}ms'.format(config.plugins.IPAudio.audioDelay.value))
            
            if config.plugins.IPAudio.running.value:
                self.restartAudioWithDelay()

    def audioDelayReset(self):
        config.plugins.IPAudio.audioDelay.value = 0
        config.plugins.IPAudio.audioDelay.save()
        self['audio_delay'].setText('Audio Delay: 0ms')
        
        if config.plugins.IPAudio.running.value:
            self.restartAudioWithDelay()

    def applyAudioDelay(self):
        if hasattr(self, 'url') and self.url:
            current_url = self.url
            
            if self.audio_process:
                try:
                    self.audio_process.terminate()
                    self.audio_process.wait(timeout=1)
                except:
                    try:
                        self.audio_process.kill()
                    except:
                        pass
                self.audio_process = None
            
            self.delayRestartTimer = eTimer()
            try:
                self.delayRestartTimer.callback.append(lambda: self.restartAudioWithDelay(current_url))
            except AttributeError:
                self.delayRestartTimer_conn = self.delayRestartTimer.timeout.connect(lambda: self.restartAudioWithDelay(current_url))
            self.delayRestartTimer.start(100, True)

    def restartAudioWithDelay(self, url=None):
        current_url = url if url else getattr(self, 'url', None)
        if current_url:
            cprint("[IPAudio] Restarting audio with new delay: {}ms".format(config.plugins.IPAudio.audioDelay.value))
            
            if self.audio_process:
                try:
                    self.audio_process.terminate()
                    self.audio_process.wait(timeout=1)
                except:
                    pass
            
            if IPAudioHandler.container.running():
                IPAudioHandler.container.kill()
            
            delay_ms = config.plugins.IPAudio.audioDelay.value
            
            if config.plugins.IPAudio.player.value == "gst1.0-ipaudio":
                sink = config.plugins.IPAudio.sync.value
                cmd = 'gst-launch-1.0 -e uridecodebin uri="{}" ! audioconvert ! audioresample ! '.format(current_url)
                
                if delay_ms != 0:
                    delay_ns = abs(delay_ms) * 1000000
                    if delay_ms > 0:
                        cmd += 'audiobuffersplit output-buffer-duration={} ! '.format(delay_ns)
                    else:
                        cmd += 'queue max-size-buffers=1 max-size-time=1000000 ! '
                
                cmd += '{} sync=false'.format(sink)
                
                if hasattr(self, 'plIndex') and self.plIndex < len(self.choices):
                    if self.choices[self.plIndex] not in self.hosts:
                        volume = config.plugins.IPAudio.volLevel.value / 10.0
                        cmd = cmd.replace('audioresample !', 'audioresample ! volume volume={} !'.format(volume))
            else:
                if delay_ms > 0:
                    cmd = 'ffmpeg -i "{}" -af "adelay={}|{}" -vn -f alsa default'.format(current_url, delay_ms, delay_ms)
                elif delay_ms < 0:
                    trim_sec = abs(delay_ms) / 1000.0
                    cmd = 'ffmpeg -ss {} -i "{}" -vn -f alsa default'.format(trim_sec, current_url)
                else:
                    cmd = 'ffmpeg -i "{}" -vn -f alsa default'.format(current_url)
            
            self.runCmd(cmd)

    def openConfig(self):
        self.session.openWithCallback(self.configClosed, IPAudioSetup)

    def configClosed(self, ret=None):
        pass

    def getEqualizerFilter(self):
        eq = config.plugins.IPAudio.equalizer.value
        
        if eq == "off":
            return None
        elif eq == "bass_boost":
            return "equalizer-3bands band0=-6.0 band1=-3.0 band2=6.0"
        elif eq == "treble_boost":
            return "equalizer-3bands band0=6.0 band1=-3.0 band2=-6.0"
        elif eq == "vocal":
            return "equalizer-3bands band0=-3.0 band1=6.0 band2=-3.0"
        elif eq == "rock":
            return "equalizer-3bands band0=5.0 band1=3.0 band2=-2.0"
        elif eq == "pop":
            return "equalizer-3bands band0=-2.0 band1=5.0 band2=3.0"
        elif eq == "classical":
            return "equalizer-3bands band0=4.0 band1=0.0 band2=-4.0"
        elif eq == "jazz":
            return "equalizer-3bands band0=3.0 band1=2.0 band2=4.0"
        
        return None

    def exit(self, ret=False):
        if self.guideTimer.isActive():
            self.guideTimer.stop()
        
        if self.statusTimer.isActive():
            self.statusTimer.stop()
        
        if ret and not self.timeShiftTimer.isActive():
            self.close()
        else:
            self.close()

class IPAudioPlaylist(IPAudioScreen):
    def __init__(self, session):
        IPAudioScreen.__init__(self, session)
        
        if isHD():
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioPlaylist_ORANGE_HD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioPlaylist_TEAL_HD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioPlaylist_LIME_HD
            else:
                self.skin = SKIN_IPAudioPlaylist_ORANGE_HD
        else:
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioPlaylist_ORANGE_FHD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioPlaylist_TEAL_FHD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioPlaylist_LIME_FHD
            else:
                self.skin = SKIN_IPAudioPlaylist_ORANGE_FHD
        
        self["key_green"] = Button("Remove Link")
        self["key_red"] = Button("Reset Playlist")
        self["IPAudioAction"] = ActionMap(["IPAudioActions"],
        {
            "cancel": self.exit,
            "green": self.keyGreen,
            "red": self.keyRed,
        }, -1)
        self.onLayoutFinish = []
        self.onShown = []
        self.loadPlaylist()

    def loadPlaylist(self):
        playlist = getPlaylist()
        if playlist:
            list = []
            for channel in playlist['playlist']:
                try:
                    list.append((str(channel['channel']), str(channel['url'])))
                except KeyError:
                    pass
            if len(list) > 0:
                self["list"].l.setList(self.iniMenu(list))
                self["server"].setText('Custom Playlist')
            else:
                self["list"].hide()
                self["server"].setText('Playlist is empty')
        else:
            self["list"].hide()
            self["server"].setText('Cannot load playlist')

    def keyRed(self):
        playlist = getPlaylist()
        if playlist:
            playlist['playlist'] = []
            with open("/etc/enigma2/ipaudio.json", 'w') as f:
                json.dump(playlist, f, indent=4)
            self.loadPlaylist()

    def keyGreen(self):
        playlist = getPlaylist()
        if playlist:
            if len(playlist['playlist']) > 0:
                index = self['list'].getSelectionIndex()
                currentPlaylist = playlist["playlist"]
                del currentPlaylist[index]
                playlist['playlist'] = currentPlaylist
                with open("/etc/enigma2/ipaudio.json", 'w') as f:
                    json.dump(playlist, f, indent=4)
                self.loadPlaylist()

    def exit(self):
        self.close()

class IPAudioInfo(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        
        if isHD():
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioInfo_ORANGE_HD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioInfo_TEAL_HD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioInfo_LIME_HD
            else:
                self.skin = SKIN_IPAudioInfo_ORANGE_HD
        else:
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioInfo_ORANGE_FHD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioInfo_TEAL_FHD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioInfo_LIME_FHD
            else:
                self.skin = SKIN_IPAudioInfo_ORANGE_FHD
        
        self.skinName = "IPAudioInfo"
        
        self["info_text"] = Label()
        self["key_red"] = Button("Close")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "ok": self.close,
            }, -1)
        
        self.onLayoutFinish.append(self.showInfo)
    
    def showInfo(self):
        info = """IPAudio v{}

Original Developer
ZIKO

Maintainer
popking159

Enjoy FREE Enigma2 world!


Press OK or RED to close
        """.format(Ver)
        
        self["info_text"].setText(info.strip())

class IPAudioHelp(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        
        if isHD():
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioHelp_ORANGE_HD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioHelp_TEAL_HD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioHelp_LIME_HD
            else:
                self.skin = SKIN_IPAudioHelp_ORANGE_HD
        else:
            if config.plugins.IPAudio.skin.value == 'orange':
                self.skin = SKIN_IPAudioHelp_ORANGE_FHD
            elif config.plugins.IPAudio.skin.value == 'teal':
                self.skin = SKIN_IPAudioHelp_TEAL_FHD
            elif config.plugins.IPAudio.skin.value == 'lime':
                self.skin = SKIN_IPAudioHelp_LIME_FHD
            else:
                self.skin = SKIN_IPAudioHelp_ORANGE_FHD
        
        self.skinName = "IPAudioHelp"
        
        from Components.Sources.List import List
        self.help_lines = []
        self["help_text"] = List(self.help_lines)
        self["key_red"] = Button("Close")
        
        self["actions"] = ActionMap(["ColorActions", "OkCancelActions", "DirectionActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "ok": self.close,
                "up": self.scrollUp,
                "down": self.scrollDown,
            }, -1)
        
        self.onLayoutFinish.append(self.showHelp)
    
    def showHelp(self):
        help_lines = [
            "BASIC CONTROLS:",
            "* OK: Play selected channel",
            "* LEFT/RIGHT: Switch between categories",
            "* UP/DOWN: Navigate channel list",
            "* EXIT: Close plugin (audio continues)",
            "",
            "AUDIO CONTROLS:",
            "* GREEN: Reset/Stop audio",
            "* 7: Decrease Audio delay (-0.5s)",
            "* 9: Increase Audio delay (+0.5s)",
            "* 8: Reset Audio delay",
            "  - Sync audio with video",
            "  - Range: -10s to +10s",
            "",
            "VIDEO SYNC:",
            "* PAUSE: Activate TimeShift delay",
            "* CH+: Increase Video delay (+0.5s)",
            "* CH-: Decrease Video delay (-0.5s)",
            "  - Sync live TV with audio stream",
            "  - Range: 0 to +50s",
            "",
            "SETTINGS (MENU):",
            "* Change skin color (Orange/Teal/Lime)",
            "* Select player (GStreamer/FFmpeg)",
            "* Configure audio output",
            "* Enable/disable updates",
            "* Adjust volume level",
            "",
            "WEB INTERFACE:",
            "* Access: http://box-ip:8080/ipaudio",
            "* Manage playlists",
            "* Create categories",
            "* Drag-and-drop channels",
            "* Add/edit/delete channels",
            "",
            "BUTTONS:",
            "* RED: Exit plugin",
            "* GREEN: Reset audio",
            "* YELLOW: Show this help",
            "* BLUE: About/Info",
            "",
            "PLAYLIST MANAGEMENT:",
            "* Create unlimited categories",
            "* Each category has separate JSON file",
            "* Files in: /etc/enigma2/ipaudio/",
            "* Format: ipaudio_<name>.json",
            "",
            "TIPS:",
            "* Use audio delay for stream sync",
            "* Use TimeShift for live TV sync",
            "* Playlists auto-reload on change",
            "* Web interface updates in real-time",
            "",
            "Press UP/DOWN to scroll",
            "Press RED or EXIT to close",
        ]
        
        self.help_lines = [(line,) for line in help_lines]
        self["help_text"].setList(self.help_lines)
    
    def scrollUp(self):
        self["help_text"].up()
    
    def scrollDown(self):
        self["help_text"].down()

class IPAudioHandler(Screen):
    container = eConsoleAppContainer()

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evEnd: self.__evEnd,
            iPlayableService.evStopped: self.__evEnd,
        })

    def stopIPAudio(self):
        if self.container.running():
            self.container.kill()

    def __evEnd(self):
        if config.plugins.IPAudio.lastplayed.value == "e2_service":
            if fileExists('/dev/dvb/adapter0/audio10') and config.plugins.IPAudio.running.value:
                self.stopIPAudio()
                os.rename('/dev/dvb/adapter0/audio10', '/dev/dvb/adapter0/audio0')
                config.plugins.IPAudio.running.value = False
                config.plugins.IPAudio.running.save()
            elif config.plugins.IPAudio.running.value and config.plugins.IPAudio.keepaudio.value or HAVE_EALSA:
                self.stopIPAudio()
            else:
                if config.plugins.IPAudio.running.value and isMutable():
                    self.stopIPAudio()
                    config.plugins.IPAudio.running.value = False
                    config.plugins.IPAudio.running.save()

class IPAudioLauncher():
    def __init__(self, session):
        self.session = session

    def gotSession(self):
        keymap = resolveFilename(SCOPE_PLUGINS, "Extensions/IPAudio/keymap.xml")
        readKeymap(keymap)
        globalActionMap.actions['IPAudioSelection'] = self.ShowHide

    def ShowHide(self):
        if not isinstance(self.session.current_dialog, IPAudioScreen):
            self.session.open(IPAudioScreen)

def sessionstart(reason, session=None, **kwargs):
    if reason == 0:
        IPAudioHandler(session)
        IPAudioLauncher(session).gotSession()
        
        try:
            from Plugins.Extensions.IPAudio.webif import startWebInterface
            from twisted.internet import reactor
            
            reactor.callLater(2, startWebInterface)
        except Exception as e:
            print("[IPAudio] Could not start web interface: {}".format(e))
            import traceback
            traceback.print_exc()

def main(session, **kwargs):
    session.open(IPAudioScreen)

def showInmenu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("IPAudio", main, "IPAudio", 1)]
    else:
        return []

def Plugins(**kwargs):
    Descriptors = []
    Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart))
    if config.plugins.IPAudio.mainmenu.value:
        Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_MENU], fnc=showInmenu))
    Descriptors.append(PluginDescriptor(name="IPAudio", description="Listen to your favorite commentators", icon="logo.png", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main))
    return Descriptors