# __ins__.py
import sys
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
